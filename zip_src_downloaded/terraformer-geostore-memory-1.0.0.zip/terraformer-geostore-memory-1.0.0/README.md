# Terraformer GeoStore - Memory

This is an in-Memory GeoStore backend for Terraformer.

More information on the Terraformer GeoStore can be found at https://github.com/Esri/terraformer-geostore
