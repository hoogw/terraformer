# Terraformer GeoStore - LocalStorage

This is a LocalStorage GeoStore backend for Terraformer.

More information on the Terraformer GeoStore can be found at https://github.com/Esri/terraformer-geostore
