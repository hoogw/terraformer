# Terraformer GeoStore - RTree

This is an RTree Index for Terraformer.

This Index is based on code originally written by Jon-Carlos Rivera, which can be found under MIT license at https://github.com/imbcmdth/RTree

More information on the Terraformer GeoStore can be found at https://github.com/Esri/terraformer-geostore
